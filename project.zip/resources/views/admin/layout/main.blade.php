@include('Admin.layout.header')

@include('Admin.layout.sidebar')

@yield('admin')


@include('Admin.layout.footer')
