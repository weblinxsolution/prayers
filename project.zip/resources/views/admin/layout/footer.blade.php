       <footer class="main-footer text-center">
           <a href="{{ Route('dashboard') }}">Tamim &copy; All Rights Reserved</a>
       </footer>
       </div>
       </div>


       <!-- General JS Scripts -->
       <script src="{{ asset('admin/assets/bundles/lib.vendor.bundle.js') }}"></script>
       <script src="{{ asset('admin/js/CodiePie.js') }}"></script>

       <!-- JS Libraies -->
       <script src="{{ asset('admin/assets/modules/jquery.sparkline.min.js') }}"></script>
       <script src="{{ asset('admin/assets/modules/chart.min.js') }}"></script>
       <script src="{{ asset('admin/assets/modules/owlcarousel2/dist/owl.carousel.min.js') }}"></script>
       <script src="{{ asset('admin/assets/modules/summernote/summernote-bs4.js') }}"></script>
       <script src="{{ asset('admin/assets/modules/chocolat/dist/js/jquery.chocolat.min.js') }}"></script>

       <!-- Page Specific JS File -->
       <script src="{{ asset('admin/js/page/index.js') }}"></script>

       <!-- Template JS File -->
       <script src="{{ asset('admin/js/scripts.js') }}"></script>
       <script src="{{ asset('admin/js/custom.js') }}"></script>

       </body>

       <!-- index.html  Tue, 07 Jan 2020 03:35:33 GMT -->

       </html>
