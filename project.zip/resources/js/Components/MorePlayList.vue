<template>
    <div class="content-widget mx-sm-0 rounded-sm-0">
        <div class="row p-4">
            <div class="col-lg-12 px-0">
                <h3 class="text-theme mb-0 rtl fw-700">قوائم أكثر تشغيلا</h3>
            </div>
            <div class="col-lg-12 px-0">
                <div class="MoreSuratBox mt-3 mb-2">
                    <div class="MoreSuratList">
                        <div class="MoreSuratList-content">
                            <div>
                                <h5>قائمة تشغيل قرأن جديدة</h5>
                                <p>ماهر المعيقلي</p>
                            </div>
                            <div>
                                <AppImage :imageSrc="MorePlayListImg" />
                            </div>
                        </div>
                        <div class="MoreSuratList-play">
                            <p class="mb-0">200 تشغيل</p>
                            <svg xmlns="http://www.w3.org/2000/svg" width="29" height="28" viewBox="0 0 29 28" fill="none">
                                <path
                                    d="M11.9383 20.3L20.3383 14L11.9383 7.7V20.3ZM14.7383 0C7.00328 0 0.738281 6.265 0.738281 14C0.738281 21.735 7.00328 28 14.7383 28C22.4733 28 28.7383 21.735 28.7383 14C28.7383 6.265 22.4733 0 14.7383 0ZM14.7383 25.2C8.56428 25.2 3.53828 20.174 3.53828 14C3.53828 7.826 8.56428 2.8 14.7383 2.8C20.9123 2.8 25.9383 7.826 25.9383 14C25.9383 20.174 20.9123 25.2 14.7383 25.2Z"
                                    fill="#1E4D45" />
                            </svg>
                        </div>
                    </div>
                    <div class="MoreSuratList">
                        <div class="MoreSuratList-content">
                            <div>
                                <h5>قائمة تشغيل قرأن جديدة</h5>
                                <p>ماهر المعيقلي</p>
                            </div>
                            <div>
                                <AppImage :imageSrc="MorePlayListImg" />
                            </div>
                        </div>
                        <div class="MoreSuratList-play">
                            <p class="mb-0">200 تشغيل</p>
                            <svg xmlns="http://www.w3.org/2000/svg" width="29" height="28" viewBox="0 0 29 28" fill="none">
                                <path
                                    d="M11.9383 20.3L20.3383 14L11.9383 7.7V20.3ZM14.7383 0C7.00328 0 0.738281 6.265 0.738281 14C0.738281 21.735 7.00328 28 14.7383 28C22.4733 28 28.7383 21.735 28.7383 14C28.7383 6.265 22.4733 0 14.7383 0ZM14.7383 25.2C8.56428 25.2 3.53828 20.174 3.53828 14C3.53828 7.826 8.56428 2.8 14.7383 2.8C20.9123 2.8 25.9383 7.826 25.9383 14C25.9383 20.174 20.9123 25.2 14.7383 25.2Z"
                                    fill="#1E4D45" />
                            </svg>
                        </div>
                    </div>
                    <div class="MoreSuratList">
                        <div class="MoreSuratList-content">
                            <div>
                                <h5>قائمة تشغيل قرأن جديدة</h5>
                                <p>ماهر المعيقلي</p>
                            </div>
                            <div>
                                <AppImage :imageSrc="MorePlayListImg" />
                            </div>
                        </div>
                        <div class="MoreSuratList-play">
                            <p class="mb-0">200 تشغيل</p>
                            <svg xmlns="http://www.w3.org/2000/svg" width="29" height="28" viewBox="0 0 29 28" fill="none">
                                <path
                                    d="M11.9383 20.3L20.3383 14L11.9383 7.7V20.3ZM14.7383 0C7.00328 0 0.738281 6.265 0.738281 14C0.738281 21.735 7.00328 28 14.7383 28C22.4733 28 28.7383 21.735 28.7383 14C28.7383 6.265 22.4733 0 14.7383 0ZM14.7383 25.2C8.56428 25.2 3.53828 20.174 3.53828 14C3.53828 7.826 8.56428 2.8 14.7383 2.8C20.9123 2.8 25.9383 7.826 25.9383 14C25.9383 20.174 20.9123 25.2 14.7383 25.2Z"
                                    fill="#1E4D45" />
                            </svg>
                        </div>
                    </div>
                    <div class="MoreSuratList">
                        <div class="MoreSuratList-content">
                            <div>
                                <h5>قائمة تشغيل قرأن جديدة</h5>
                                <p>ماهر المعيقلي</p>
                            </div>
                            <div>
                                <AppImage :imageSrc="MorePlayListImg" />
                            </div>
                        </div>
                        <div class="MoreSuratList-play">
                            <p class="mb-0">200 تشغيل</p>
                            <svg xmlns="http://www.w3.org/2000/svg" width="29" height="28" viewBox="0 0 29 28" fill="none">
                                <path
                                    d="M11.9383 20.3L20.3383 14L11.9383 7.7V20.3ZM14.7383 0C7.00328 0 0.738281 6.265 0.738281 14C0.738281 21.735 7.00328 28 14.7383 28C22.4733 28 28.7383 21.735 28.7383 14C28.7383 6.265 22.4733 0 14.7383 0ZM14.7383 25.2C8.56428 25.2 3.53828 20.174 3.53828 14C3.53828 7.826 8.56428 2.8 14.7383 2.8C20.9123 2.8 25.9383 7.826 25.9383 14C25.9383 20.174 20.9123 25.2 14.7383 25.2Z"
                                    fill="#1E4D45" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import AppImage from "../Components/Image.vue";
export default {
    data() {
        return {
            MorePlayListImg: 'templates/playlists/playlist.png',
        }
    },
    components: {
        AppImage
    }
}
</script>